# Ludo Board Game
 
 <h1>Language Used </h1>
 <p>Html, Css & Javascript</p>
<hr>
<h1>About This Game</h1>
<p>This is Responsive for Both Mobile and Laptop/Pc</p>

You can play it at
-https://whomonugiri.github.io/ludo-board/

feel free to suggest edits
